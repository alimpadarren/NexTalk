<?php 
require_once 'includes/auth.php'; 
checkLogin(); 

$my_id = $_SESSION['user_id'];
$my_username = $_SESSION['username'];
$my_avatar = $_SESSION['avatar'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexTalk - Connect. Communicate. Belong.</title>
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>💬</text></svg>">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="app-container">
        <!-- LEFT SIDEBAR -->
        <aside class="sidebar">
            <div class="logo-container">
                <div class="logo-icon">💬</div>
                <div class="logo-text">Nex<span>Talk</span></div>
            </div>
            
            <nav class="menu">
                <a href="#" class="menu-item active" id="tab-messages">
                    <span class="icon">💬</span> Messages
                </a>
                <a href="#" class="menu-item" id="tab-users">
                    <span class="icon">👥</span> Users
                </a>
                <a href="#" class="menu-item" id="tab-groups">
                    <span class="icon">👥</span> Groups
                </a>
            </nav>

            <div class="my-profile-section">
                <div class="my-profile-card">
                    <img src="<?= htmlspecialchars($my_avatar) ?>" alt="Me" class="my-profile-avatar">
                    <h3><?= htmlspecialchars($my_username) ?></h3>
                    <p class="status online"><span class="dot"></span> Online</p>
                    <button id="open-profile-modal" class="edit-profile-btn">✏️ Edit Profile</button>
                </div>
            </div>

            <div class="theme-toggle-wrapper">
                <button id="theme-toggle" class="theme-toggle-btn">🌙 Dark Mode</button>
            </div>

            <a href="logout.php" class="logout-link">
                <button class="logout-btn">Logout</button>
            </a>
        </aside>

        <!-- MIDDLE CHAT LIST -->
        <div class="chat-list">
            <div class="search-bar">
                <input type="text" placeholder="🔍 Search users...">
            </div>
            
            <div id="create-group-wrapper" style="padding: 10px 20px; display: none;">
                <button id="create-group-btn" style="width:100%; padding:10px; background:#0052ff; color:white; border:none; border-radius:10px; font-weight:600; cursor:pointer;">➕ Create Group</button>
            </div>
            
            <div id="messages-list-view"></div>
            <div id="users-list-view" style="display: none;"></div>
            <div id="groups-list-view" style="display: none;"></div>
        </div>

        <!-- MAIN CHAT AREA -->
        <main class="chat-area">
            <header class="chat-header">
                <div class="chat-user-info">
                    <img id="current-chat-avatar" src="https://i.pravatar.cc/150?img=47" alt="User">
                    <div>
                        <h2 id="current-chat-name">Select a user</h2>
                        <p class="status online"><span class="dot"></span> Online</p>
                    </div>
                </div>
                <div class="chat-actions">
                    <button class="icon-btn" id="call-btn" title="Call">📞</button>
                    <button class="icon-btn" id="info-btn" title="Info">ℹ️</button>
                </div>
            </header>

            <div class="messages-container" id="messages-container">
                <p style="text-align:center; color:#94a3b8; margin-top:20px;">Select a user to start chatting!</p>
            </div>

            <div class="message-input-area">
                <div class="emoji-picker-wrapper">
                    <button class="icon-btn" id="emoji-btn">😀</button>
                    <div id="emoji-picker" class="emoji-picker">
                        <div id="emoji-categories" class="emoji-categories"></div>
                        <div id="emoji-list" class="emoji-list"></div>
                    </div>
                </div>
                <input type="text" id="message-input" placeholder="Type a message...">
                <input type="file" id="image-input" accept="image/*" style="display: none;">
                <button class="icon-btn" id="attach-btn" title="Attach image">📎</button>
                <button class="icon-btn" id="voice-btn" title="Voice message">🎤</button>
                <button class="send-btn">➤</button>
            </div>

            <!-- Image Preview Modal -->
            <div id="image-preview-modal" class="image-modal">
                <img id="preview-img" class="preview-img">
                <button id="close-preview" class="close-preview">×</button>
            </div>
        </main>
    </div>

    <!-- PROFILE MODAL -->
    <div id="profile-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>Edit Profile</h2>
            <div class="avatar-preview-wrapper">
                <img id="modal-avatar-preview" src="<?= htmlspecialchars($my_avatar) ?>" class="modal-avatar">
                <label for="modal-avatar-input" class="camera-badge">📷</label>
                <input type="file" id="modal-avatar-input" accept="image/*" style="display:none;">
            </div>
            <div class="avatar-tabs">
                <button type="button" class="avatar-tab active-tab" data-tab="upload">📁 Upload</button>
                <button type="button" class="avatar-tab" data-tab="camera">📸 Camera</button>
                <button type="button" class="avatar-tab" data-tab="avatars">🎨 Defaults</button>
            </div>
            <div id="tab-upload" class="avatar-tab-content" style="display:block;">
                <p style="font-size:12px; color:#64748b;">Click the 📷 icon above or drag an image here.</p>
            </div>
            <div id="tab-camera" class="avatar-tab-content" style="display:none;">
                <video id="camera-video" autoplay playsinline class="camera-video"></video>
                <button type="button" id="capture-btn" class="capture-btn">📸 Take Photo</button>
            </div>
            <div id="tab-avatars" class="avatar-tab-content" style="display:none;">
                <div class="avatars-grid">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" class="default-avatar">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka" class="default-avatar">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Jack" class="default-avatar">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Mia" class="default-avatar">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Leo" class="default-avatar">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Zoe" class="default-avatar">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Max" class="default-avatar">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Luna" class="default-avatar">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Sam" class="default-avatar">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Nala" class="default-avatar">
                </div>
            </div>
            <input type="hidden" id="selected-default-avatar" value="">
            <input type="hidden" id="camera-captured-data" value="">
            <input type="text" id="modal-username-input" value="<?= htmlspecialchars($my_username) ?>" placeholder="Username" class="modal-username-input">
            <div class="modal-actions">
                <button id="profile-cancel" class="btn-cancel">Cancel</button>
                <button id="profile-save" class="btn-save">Save Changes</button>
            </div>
        </div>
    </div>

    <!-- CALL MODAL -->
    <div id="call-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>📞 Audio Call</h2>
            <img id="call-avatar" src="" class="modal-avatar" style="margin:20px auto;">
            <h3 id="call-username" style="color:#0f172a; margin-bottom:10px;"></h3>
            <p style="color:#64748b; margin-bottom:20px;">Calling feature coming soon!</p>
            <div class="modal-actions">
                <button id="call-close" class="btn-cancel">Close</button>
            </div>
        </div>
    </div>

    <!-- INFO MODAL -->
    <div id="info-modal" class="modal-overlay">
        <div class="modal-content">
            <h2>ℹ️ Contact Info</h2>
            <img id="info-avatar" src="" class="modal-avatar" style="margin:20px auto;">
            <h3 id="info-username" style="color:#0f172a;"></h3>
            <p id="info-status" style="color:#64748b; margin-top:8px;"></p>
            <p style="color:#94a3b8; font-size:12px; margin-top:15px;">NexTalk Member</p>
            <div class="modal-actions" style="margin-top:20px;">
                <button id="info-close" class="btn-cancel">Close</button>
            </div>
        </div>
    </div>

    <footer class="app-footer">
        <p>© 2025 NexTalk. All rights reserved.</p>
        <p>💙 Simple. Fast. Reliable.</p>
    </footer>

    <script>
        const MY_ID = <?= $my_id ?>;
        const MY_AVATAR = "<?= htmlspecialchars($my_avatar) ?>";
        (function() {
            const saved = localStorage.getItem('nextalk-theme');
            if (saved === 'dark') document.body.classList.add('dark-mode');
        })();
    </script>
    <script src="assets/js/chat.js?v=<?= time() ?>"></script>
</body>
</html>