<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$groupId = (int)($data['group_id'] ?? 0);
$message = trim($data['message'] ?? '');

if ($groupId <= 0 || $message === '') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid']);
    exit;
}

$my_id = (int)$_SESSION['user_id'];

$check = $pdo->prepare("SELECT 1 FROM chat_group_members WHERE group_id = ? AND user_id = ?");
$check->execute([$groupId, $my_id]);
if (!$check->fetch()) {
    echo json_encode(['status' => 'error', 'message' => 'Not a member']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO messages (sender_id, group_id, message) VALUES (?, ?, ?)");
$stmt->execute([$my_id, $groupId, $message]);

echo json_encode(['status' => 'success']);
?>