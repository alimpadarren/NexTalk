<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$name = trim($data['name'] ?? '');
$memberIds = $data['members'] ?? [];

if (strlen($name) < 2) {
    echo json_encode(['status' => 'error', 'message' => 'Group name too short']);
    exit;
}

$my_id = (int)$_SESSION['user_id'];

try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO chat_groups (name, creator_id) VALUES (?, ?)");
    $stmt->execute([$name, $my_id]);
    $groupId = (int)$pdo->lastInsertId();
    
    $allMembers = array_unique(array_merge([$my_id], array_map('intval', $memberIds)));
    $stmt = $pdo->prepare("INSERT INTO chat_group_members (group_id, user_id) VALUES (?, ?)");
    foreach ($allMembers as $uid) {
        if ($uid > 0) $stmt->execute([$groupId, $uid]);
    }
    $pdo->commit();
    
    echo json_encode(['status' => 'success', 'group_id' => $groupId, 'name' => $name]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>