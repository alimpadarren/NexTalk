<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$groupId = (int)($_GET['group_id'] ?? 0);
$my_id = (int)$_SESSION['user_id'];

if ($groupId <= 0) {
    echo json_encode([]);
    exit;
}

$check = $pdo->prepare("SELECT 1 FROM chat_group_members WHERE group_id = ? AND user_id = ?");
$check->execute([$groupId, $my_id]);
if (!$check->fetch()) {
    echo json_encode([]);
    exit;
}

$stmt = $pdo->prepare("
    SELECT m.*, u.username, u.avatar 
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.group_id = ?
    ORDER BY m.created_at ASC
");
$stmt->execute([$groupId]);
echo json_encode($stmt->fetchAll());
?>