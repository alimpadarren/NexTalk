<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$my_id = (int)$_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT g.id, g.name, g.creator_id,
    (SELECT COUNT(*) FROM chat_group_members WHERE group_id = g.id) as member_count
    FROM chat_groups g
    JOIN chat_group_members gm ON gm.group_id = g.id
    WHERE gm.user_id = ?
    ORDER BY g.created_at DESC
");
$stmt->execute([$my_id]);
echo json_encode($stmt->fetchAll());
?>